/*
NAME: Arnav Garg
EMAIL ID: arnavgrg@ucla.edu
UID: 304911796
*/

//Import libraries 
#include <stdio.h> //printf()
#include <errno.h> //defines the integer variable errno
#include <unistd.h> //getopt_long(), execvp()
#include <getopt.h> //struct for getoptlong
#include <stdlib.h> //exit(), malloc()
#include <fcntl.h> //open() + File access modes used for open() O_RDONLY etc.
#include <sys/types.h> //Needed for open and creat, fork
#include <sys/stat.h> //Needed for open and creat
#include <string.h> //String functions (if needed), atoi

//Macros that can be reused throughout the program
#define rd 'r'
#define wr 'w'
#define comm 'c'
#define verb 'v'

//Main function to do all the work
int main(int argc, char* argv[]){

    //Needed for getopt_long
    int choice;
    //Set option_index for getopt_long
    int option_index = 0;

    //Set to 1 if --verbose is passed in
    int verbose_flag = 0; 
    
    //Array to keep track of all the file descriptors so far
    int fileds[argc];
    //Variable to keep track of number of fileds in fileds array.
    int numfiles = 0;

    //errorFlag
    int errorFlag = 0;
    //Separate error flag for command
    int commandErrorFlag = 0;

    //Struct containing flags that can passed through cmd
    static struct option choices[] = {
        {"rdonly",required_argument,NULL,rd},
        {"wronly",required_argument,NULL,wr},
        {"command",required_argument,NULL,comm},
        {"verbose",no_argument,NULL,verb},
        {0,0,0,0}
    };

    //Parse command line arguments/flags incrementally
    while ((choice = getopt_long(argc, argv, "", choices, &option_index)) != -1){

        //Non-options array for command flag
        //Automatically get reset each time the while loop is called
        char* params[argc];
        int paramIndex = 0;

        //If verbose flag is turned on, write commands to stdout.
        if (verbose_flag) {
            //Write flag name to output
            fprintf(stdout,"--%s",choices[option_index].name);
            fflush(stdout);
            //Set curr to the first non-option
            int curr = optind-1;
            //Keep recursing through argv vector
            while (curr < argc) {
                //Set s to temporary 
                char* s = argv[curr];
                //Stop when the next flag is detected
                if (strlen(s) > 2) {
                    if (s[0]=='-' && s[1]=='-') {
                        break;
                    }
                }
                //Print to stdout
                fprintf(stdout, " %s", s);
                fflush(stdout);
                //Increment optind by 1
                curr++;
            }
            //Print a new line
            fprintf(stdout, "\n");
            fflush(stdout);
        }
        
        //Switch case to detect which flag was detected
        switch (choice) {
            case rd: 
                /*optarg contains argument for the given flag*/
                /*incase of error/failure, optarg is set to null*/
                if (optarg) {
                    //Open file passed in using readonly flag.
                    int fd = open(optarg, O_RDONLY);
                    //If not a valid file descriptor returned
                    if (fd < 0) {
                        fprintf(stderr, "Cannot read from file: %d - %s\n", errno, strerror(errno));
                        //Flush stderr
                        fflush(stderr);
                        //Set error flag to 1
                        errorFlag = 1;
                        //Append this invalid file descriptor to fileds array
                        fileds[numfiles] = fd;
                        //Incremenet number of file descriptors in array by 1.
                        numfiles += 1;
                    } 
                    //If valid 
                    else {
                        fileds[numfiles] = fd;
                        //Incremenet number of fileds in array by 1.
                        numfiles += 1;
                    }
                }
                break;
            case wr:
                if (optarg) {
                    //Open file passed in using writeonly sflag.
                    int fd = open(optarg, O_WRONLY);
                    //If the returned file descriptor is >= 0
                    if (fd < 0){
                        //File could not be created/truncated. Print to stderr and exit with status 3.
                        //char buffer[] = "Cannot create or truncate output file:  %d - %s";
                        fprintf(stderr, "Cannot create or truncate output file:  %d - %s\n", errno, strerror(errno));
                        //Flush stderr
                        fflush(stderr);
                        //Set error flag to 1
                        errorFlag = 1;
                        fileds[numfiles] = fd;
                        numfiles += 1;
                    } else {
                        fileds[numfiles] = fd;
                        numfiles += 1;
                    }
                }
                break;
            case verb:
                //If verbose flag is passed in, set verbose_flag to 1. 
                verbose_flag = 1;
                break;
            case comm:
                //find all the parameters passed in after the --command flag
                paramIndex = 0;
                commandErrorFlag = 0;
                //Go through all the remaining arguments in the argv array
                optind--;
                while (optind < argc) {
                    //Set opt to the non-option
                    char* opt = argv[optind];
                    //Make sure opt isn't a flag
                    if (strlen(opt) > 1) {
                        if (*(opt+1) == '-'){
                            break;
                        }
                    }
                    //Append opt to options index
                    params[paramIndex] = opt;
                    //Increment index by 1
                    paramIndex++;
                    //Increment optind by 1 to move to the next option in argv
                    optind++;
                }
                //Need to set the last element in params to NULL so 
                //that execvp can be called correctly 
                params[paramIndex] = NULL;
                //Incrememnt paramIndex by 1 (also keeps track of number 
                //of elements in paramIndex)
                paramIndex++;
                //Create an integer array of file descriptors used 
                int input = atoi(params[0]);
                int output = atoi(params[1]);
                int error = atoi(params[2]);
              
                //Check if file desctiptors passed in are valid
                //Need to convert the first 3 arguments from strings to numbers
                //so that they can be used as valid file desriptors
                if (input < 0 || input >= numfiles){
                    commandErrorFlag = 1;
                }
                if (output < 0 || output >= numfiles){
                    commandErrorFlag = 1;
                }
                if (error < 0 || error >= numfiles){
                    commandErrorFlag = 1;
                }
                //If error flag detected, write to stderr.
                if (commandErrorFlag) {
                    errorFlag = 1;
                    fprintf(stderr,"Invalid file descriptor\n");
                    //Flush stderr after writing to it.
                    fflush(stderr);
                    //Break
                    break;
                }
                //Use fork to create a new child process
                int pid = fork();
                //If 0 is returned, it is the child process, otherwise it is 
                //the parent process. If it returns -1, child process creation was unsuccessful.
                if (pid < 0){
                    fprintf(stderr, "Error creating child process", errno, strerror(errno));
                    //Flush stderr after writing to it.
                    fflush(stderr);
                    commandErrorFlag = 1;
                    break;
                }
                //Child process
                if (pid == 0) {
                    //Close file descriptors as needed.
                    close(0);
                    dup2(fileds[input],0);
                    close(fileds[input]);

                    close(1);
                    dup2(fileds[output],1);
                    close(fileds[output]);

                    close(2);
                    dup2(fileds[error],2);
                    close(fileds[error]);
                    
                    //Call execvp to run the command in the child process.
                    if ((execvp(params[3], &params[3])) < 0) {
                        fprintf(stderr, "Error running command", errno, strerror(errno));
                        //Flush stderr after writing to it.
                        fflush(stderr);
                        commandErrorFlag = 1;
                    }
                }
                break;
            default:
                //Print to stderr and return with status 1.
                fprintf(stderr, "Only valid flags are: --rdonly, --wronly, --verbose and --command\n");
                fflush(stderr);
                errorFlag = 1;
                break;
        }
    }

    //Close all file descriptors after using them.
    for (int i=0; i < numfiles; i++) {
        close(fileds[i]);
    }

    //If no errors, exit with code 0.
    if (commandErrorFlag){
        exit(commandErrorFlag);
    }
    exit(errorFlag);
}